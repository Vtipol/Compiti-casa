using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class plot : MonoBehaviour
{

    [Header("References")]
    [SerializeField] private SpriteRenderer sr;
    [SerializeField] private Color hoverColor;

    private GameObject Tower;
    private Color startColor;

    private void Start()
    {
       
        if (sr == null)
        {
            sr = GetComponent<SpriteRenderer>();
            if (sr == null)
            {
                Debug.LogError("SpriteRenderer component not found on " + gameObject.name);
                return;
            }
        }

        startColor = sr.color;
    }

    private void OnMouseEnter()
    {
        Debug.Log("Mouse entered " + gameObject.name);
        sr.color = hoverColor;
    }

    private void OnMouseExit()
    {
        Debug.Log("Mouse exited " + gameObject.name);
        sr.color = startColor;
    }

    private void OnMouseDown()
    {
        if (Tower != null) return;
        Tower Towertobuild = Buildmanager.main.selectedGameobject();
        if (Towertobuild.Cost > LevelManager.main.currency)
        {
            Debug.Log("you can't afford this tower");
            return;
        }
        LevelManager.main.spendcurrency(Towertobuild.Cost);

        Tower = Instantiate(Towertobuild.Prefab, transform.position, Quaternion.identity);

    }
}
