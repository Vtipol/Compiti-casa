using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Rigidbody2D rb;

    [Header("Attributes")]
    [SerializeField] private float bulletspeed = 5f;
    [SerializeField] private int bulletDamage = 1;
    private float lifetime = 5f;

    private void Start()
    { 
        Destroy(gameObject, lifetime);
    }
    private Transform Target;

    public void SetTarget(Transform _target)
    {
        Target = _target;
    }

    private void FixedUpdate()
    {
        if (!Target) return;
        Vector2 direction = (Target.position - transform.position).normalized;

        rb.velocity = direction * bulletspeed;
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        other.gameObject.GetComponent<Health>().Takedamage(bulletDamage);

        if (other.CompareTag("Enemy"))
        {

            Destroy(gameObject);
        }
    }
}