using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Buildmanager : MonoBehaviour
{
    public static Buildmanager main;

    [Header("References")]
    // [SerializeField] private GameObject[] towerPrefabs
    [SerializeField] private Tower [] towers;

    private int selectedTower = 0;

    private void Awake()
    {
        main = this;
    }

    public Tower selectedGameobject()
    {
        return towers[selectedTower];
    }

    public void SetSelectedTower(int _selectedtower)
    {
        selectedTower = _selectedtower;
    }

}
