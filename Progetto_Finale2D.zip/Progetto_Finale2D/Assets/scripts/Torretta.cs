using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.UIElements;

public class Torretta : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Transform Turretrotatepoint;
    [SerializeField] private LayerMask enemymask;
    [SerializeField] private GameObject bulletprefab;
    [SerializeField] private Transform firingPoint;

    [Header("Attributes")]
    [SerializeField] private float targetinrange = 7f;
    [SerializeField] private float rotationspeed = 5f;
    [SerializeField] private float bps = 1f;
    private Transform target;
    private float timeuntilfire;
    private void Update()
    {if(!target)
        {
            Findtarget();
            return;
        }
        rotatetowrdstarget();

        if(!checkiftargetisinrange())
        {
            target = null;
        }else
        {
            timeuntilfire += Time.deltaTime;
            if (timeuntilfire >= 1f/bps)
            {
                Shoot();
            }
        }
    }
    private void Shoot()
    {
        GameObject Bulletobj = Instantiate(bulletprefab, firingPoint.position, Quaternion.identity);
        Bullet bulletscript = Bulletobj.GetComponent<Bullet>();
        bulletscript.SetTarget(target);
    }
    private void Findtarget()
    {
        RaycastHit2D[] hits = Physics2D.CircleCastAll(transform.position,targetinrange, (Vector2)
        transform.position, 0f, enemymask);
        if(hits.Length> 0)
        {
            target = hits[0].transform;
        }
       

    }
    private bool checkiftargetisinrange()
    {
        return Vector2.Distance(target.position, transform.position) <= targetinrange;
    }
    private void rotatetowrdstarget()
    {
        float angle = Mathf.Atan2(target.position.y - transform.position.y, target.position.x -
transform.position.x) * Mathf.Rad2Deg + (-90f);
        Quaternion targetRotation = Quaternion.Euler(new Vector3(0f, 0f, angle));
        transform.rotation = Quaternion.RotateTowards(Turretrotatepoint.rotation,
            targetRotation,rotationspeed*Time.deltaTime);
    }

    private void OnDrawGizmos()
    {
        Handles.color = Color.cyan;
        Handles.DrawWireDisc(transform.position, transform.forward, targetinrange) ;

    }
}
