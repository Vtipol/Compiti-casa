using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Health : MonoBehaviour
{
    [Header("Attributes")]
    [SerializeField] private int hitpoints = 20;
    [SerializeField] private int CurrencyWorth = 50;

    private bool isDestroyed = false;

    public void Takedamage(int dmg)
    {
        hitpoints -= dmg;
        if (hitpoints <= 0 && !isDestroyed)
        {
            Enemyspawner.OnenemyDestroy.Invoke();
            LevelManager.main.IncreaseCurrency(CurrencyWorth);
            isDestroyed = true;
            Destroy(gameObject);
        }
    }
}
