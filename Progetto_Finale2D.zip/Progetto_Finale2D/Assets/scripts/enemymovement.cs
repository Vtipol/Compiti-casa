using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemymovement : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Rigidbody2D rb;

    [Header("Attributes")]
    [SerializeField] private float movespeed = 2f;

    private Transform target;
    private int pathindex = 0;
    private void Start()
    {
        target = LevelManager.main.Pass[pathindex];
    }

    private void Update()
    {
        if(target != null && Vector2.Distance(target.position, transform.position) <= 0.1)
        {
            pathindex++;
            if (pathindex == LevelManager.main.Pass.Length)
            {
                Enemyspawner.OnenemyDestroy.Invoke();
                Destroy(gameObject);
                return;
            }
            else
            {
                target = LevelManager.main.Pass[pathindex];
            }
        }
                    
    }
    private void FixedUpdate()
    {
        if (target != null)
        {
            Vector2 direction = (target.position - transform.position).normalized;
            rb.velocity = direction * movespeed;
        }
    }

}
