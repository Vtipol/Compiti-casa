using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Enemyspawner : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private GameObject[] enemyprefabs;

    [Header("Attributes")]
    [SerializeField] private int baseenemy = 8;
    [SerializeField] private float enemiespersecond = 0.5f;
    [SerializeField] private float timebetweenwaves = 5f;
    [SerializeField] private float difficultyscalingfactor = 0.75f;
    [Header("Events")]
    public static UnityEvent OnenemyDestroy = new UnityEvent();
    private void Awake()
    {
        OnenemyDestroy.AddListener(Enemydestroyed);
    }

    private int Currentwave = 1;
    private float timesincelastspawn ;
    private int enemiesalive ;
    private int enemieslefttospawn ;
    private bool isspawning = false;
    private void Start()
    {
        StartCoroutine(StartWave());
    }

    private void Update()
    {
        if (!isspawning) return;
        timesincelastspawn += Time.deltaTime;
        if(timesincelastspawn >= (1f/enemiespersecond) && enemieslefttospawn > 0)
        {
            SpawnEnemy();
            enemieslefttospawn--;
            enemiesalive++;
            timesincelastspawn = 0f;
        }
        if (enemiesalive == 0 && enemieslefttospawn == 0)
        {
            EndWave();
        }
    }
    private void EndWave()
    {
        isspawning = false;
        timesincelastspawn = 0f;
        StartCoroutine(StartWave());
    }
    private void Enemydestroyed()
    {
        enemiesalive--;
    }
    private IEnumerator StartWave()
    {
        yield return new WaitForSeconds(timebetweenwaves);
        isspawning = true;
        enemieslefttospawn = enemiesperwave();
    }
    private void SpawnEnemy()
    {
        GameObject prefabspawn = enemyprefabs[0];
        Instantiate(prefabspawn, LevelManager.main.start.position, Quaternion.identity);
    }

    private int enemiesperwave()
    {
        return Mathf.RoundToInt(baseenemy * Mathf.Pow(Currentwave, difficultyscalingfactor));
    }
}

